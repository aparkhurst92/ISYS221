package com.zybooks.test1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputTemp;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        inputTemp = findViewById(R.id.inputTemp);
        resultText = findViewById(R.id.resultText);
        Button btnCtoF = findViewById(R.id.btnCtoF);
        Button btnFtoC = findViewById(R.id.btnFtoC);

        btnCtoF.setOnClickListener(v -> convertCtoF());
        btnFtoC.setOnClickListener(v -> convertFtoC());
    }

    private void convertCtoF() {
        String input = inputTemp.getText().toString();
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter a value!", Toast.LENGTH_SHORT).show();
            return;
        }
        double celsius = Double.parseDouble(input);
        double fahrenheit = TemperatureConverter.cToF(celsius);
        resultText.setText(String.format("%.2f °F", fahrenheit));
    }

    private void convertFtoC() {
        String input = inputTemp.getText().toString();
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter a value!", Toast.LENGTH_SHORT).show();
            return;
        }
        double fahrenheit = Double.parseDouble(input);
        double celsius = TemperatureConverter.fToC(fahrenheit);
        resultText.setText(String.format("%.2f °C", celsius));
    }

    //AppBar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_about) {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_website) {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.metric-conversions.org/temperature/celsius-to-fahrenheit.htm"));
            startActivity(browserIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
