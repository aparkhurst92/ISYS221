package com.zybooks.test1;

public class TemperatureConverter {
    public static double cToF(double celsius) {
        return (celsius * 9/5) + 32;
    }

    public static double fToC(double fahrenheit) {
        return (fahrenheit - 32) * 5/9;
    }
}


